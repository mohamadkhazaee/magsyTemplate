<?php if ( class_exists( 'Magsy_Essentials' ) ) {
  Magsy_Essentials::magsy_entry_action();
}