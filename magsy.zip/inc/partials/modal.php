<div class="modal">
  <div class="modal-thumbnail">
    <img class="lazyload" data-src="" src="data:image/gif;base64,R0lGODlhAQABAAAAACH5BAEKAAEALAAAAAABAAEAAAICTAEAOw==" alt="">
  </div>
  <p class="modal-title"></p>
  <div class="modal-share">
    <a class="facebook" href="#" target="_blank"><i class="mdi mdi-facebook"></i></a>
    <a class="twitter" href="#" target="_blank"><i class="mdi mdi-twitter"></i></a>
    <a class="google" href="#" target="_blank"><i class="mdi mdi-google-plus"></i></a>
    <a class="linkedin" href="#" target="_blank"><i class="mdi mdi-linkedin"></i></a>
    <a class="pinterest" href="#" target="_blank"><i class="mdi mdi-pinterest"></i></a>
    <a class="reddit" href="#" target="_blank"><i class="mdi mdi-reddit"></i></a>
    <a class="tumblr" href="#" target="_blank"><i class="mdi mdi-tumblr"></i></a>
    <a class="vk" href="#" target="_blank"><i class="mdi mdi-vk"></i></a>
    <a class="pocket" href="#" target="_blank"><i class="mdi mdi-pocket"></i></a>
    <a class="whatsapp" href="#"><i class="mdi mdi-whatsapp"></i></a>
    <a class="telegram" href="#"><i class="mdi mdi-telegram"></i></a>
  </div>
  <form class="modal-form inline">
    <input class="modal-permalink inline-field" type="text" value="">
    <button data-clipboard-text="" type="submit"><i class="mdi mdi-content-copy"></i></button>
  </form>
</div>