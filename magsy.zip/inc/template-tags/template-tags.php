<?php
require get_template_directory() . '/inc/template-tags/logo.php';
require get_template_directory() . '/inc/template-tags/entry-media.php';
require get_template_directory() . '/inc/template-tags/entry-header.php';
require get_template_directory() . '/inc/template-tags/comment.php';
require get_template_directory() . '/inc/template-tags/ads.php';